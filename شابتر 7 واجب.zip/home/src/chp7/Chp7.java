/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hom;

import java.io.FileReader;

/**
 *
 * 
 */
public class hom{

    /**
     * @param args the command line arguments
     */


public static void main(String args[]){
   Threads a = new Threads ("c:\\d.txt");
Threads b = new Threads ("c:\\d2.txt");
a.start();
  b.start();
}
}

        // TODO code application logic here
    
    

